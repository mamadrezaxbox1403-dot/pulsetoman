package com.example.textwatcher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var etInterval: TextInputEditText
    private lateinit var etMinChars: TextInputEditText
    private lateinit var etAlarmSecs: TextInputEditText
    private lateinit var etAnimSecs: TextInputEditText
    private lateinit var etMessage: TextInputEditText
    private lateinit var togglePos: MaterialButtonToggleGroup
    private lateinit var swBorder: MaterialSwitch
    private lateinit var swVibrate: MaterialSwitch
    private lateinit var tvSound: TextView

    private val projLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                saveSettings()
                val i = Intent(this, WatcherService::class.java)
                    .setAction(WatcherService.ACTION_START)
                    .putExtra(WatcherService.EXTRA_CODE, r.resultCode)
                    .putExtra(WatcherService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                moveTaskToBack(true)
            } else toast("اجازه ضبط صفحه داده نشد")
        }

    private val soundPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                prefs.soundUri = uri.toString()
                refreshSoundLabel()
            }
        }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        etInterval = findViewById(R.id.etInterval)
        etMinChars = findViewById(R.id.etMinChars)
        etAlarmSecs = findViewById(R.id.etAlarmSecs)
        etAnimSecs = findViewById(R.id.etAnimSecs)
        etMessage = findViewById(R.id.etMessage)
        togglePos = findViewById(R.id.togglePos)
        swBorder = findViewById(R.id.swBorder)
        swVibrate = findViewById(R.id.swVibrate)
        tvSound = findViewById(R.id.tvSound)

        loadSettings()
        refreshSoundLabel()

        findViewById<MaterialButton>(R.id.btnSound).setOnClickListener {
            soundPicker.launch(arrayOf("audio/*"))
        }
        findViewById<MaterialButton>(R.id.btnSoundDefault).setOnClickListener {
            prefs.soundUri = null; refreshSoundLabel()
        }
        findViewById<MaterialButton>(R.id.btnTestSound).setOnClickListener { testSound() }
        findViewById<MaterialButton>(R.id.btnStart).setOnClickListener { beginWatching() }
        findViewById<MaterialButton>(R.id.btnStop).setOnClickListener {
            if (WatcherService.running) {
                startService(Intent(this, WatcherService::class.java)
                    .setAction(WatcherService.ACTION_STOP))
            } else toast("سرویس در حال اجرا نیست")
        }
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    private fun beginWatching() {
        if (!Settings.canDrawOverlays(this)) {
            toast("اجازه «نمایش روی سایر برنامه‌ها» را روشن کنید و برگردید")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        if (WatcherService.running) { toast("سرویس همین الان فعال است"); return }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun testSound() {
        saveSettings()
        val p = AlarmPlayer(this)
        p.start(prefs.soundUri, prefs.vibrate)
        Handler(Looper.getMainLooper()).postDelayed({ p.stop() }, 3000)
    }

    private fun refreshSoundLabel() {
        tvSound.text = if (prefs.soundUri == null) "صدای فعلی: آلارم پیش‌فرض گوشی"
        else "صدای فعلی: فایل انتخاب‌شده"
    }

    private fun loadSettings() {
        etInterval.setText(prefs.intervalSec.toString())
        etMinChars.setText(prefs.minChars.toString())
        etAlarmSecs.setText(prefs.alarmSecs.toString())
        etAnimSecs.setText(prefs.animSecs.toString())
        etMessage.setText(prefs.message)
        togglePos.check(when (prefs.position) {
            0 -> R.id.posTop
            2 -> R.id.posBottom
            else -> R.id.posCenter
        })
        swBorder.isChecked = prefs.borderFlash
        swVibrate.isChecked = prefs.vibrate
    }

    private fun saveSettings() {
        prefs.intervalSec = (etInterval.text.toString().toFloatOrNull() ?: 1.5f).coerceAtLeast(0.3f)
        prefs.minChars = (etMinChars.text.toString().toIntOrNull() ?: 3).coerceAtLeast(1)
        prefs.alarmSecs = (etAlarmSecs.text.toString().toIntOrNull() ?: 8).coerceAtLeast(1)
        prefs.animSecs = (etAnimSecs.text.toString().toIntOrNull() ?: 10).coerceAtLeast(0)
        prefs.message = etMessage.text.toString().ifBlank { "متن تشخیص داده شد!" }
        prefs.position = when (togglePos.checkedButtonId) {
            R.id.posTop -> 0
            R.id.posBottom -> 2
            else -> 1
        }
        prefs.borderFlash = swBorder.isChecked
        prefs.vibrate = swVibrate.isChecked
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
