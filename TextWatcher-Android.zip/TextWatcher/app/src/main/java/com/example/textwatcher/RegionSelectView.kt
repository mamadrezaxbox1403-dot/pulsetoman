package com.example.textwatcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Full-screen overlay: drag to choose the scan area. A simple tap cancels. */
class RegionSelectView(context: Context, private val onResult: (Rect?) -> Unit) : View(context) {

    private val dim = Paint().apply { color = 0xAA000000.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EF4444"); style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 48f; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val label2 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D1D5DB"); textSize = 38f; textAlign = Paint.Align.CENTER
    }

    private var sx = 0f; private var sy = 0f
    private var ex = 0f; private var ey = 0f
    private var dragging = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (!dragging) {
            c.drawRect(0f, 0f, w, h, dim)
        } else {
            val l = min(sx, ex); val r = max(sx, ex)
            val t = min(sy, ey); val b = max(sy, ey)
            c.drawRect(0f, 0f, w, t, dim)
            c.drawRect(0f, b, w, h, dim)
            c.drawRect(0f, t, l, b, dim)
            c.drawRect(r, t, w, b, dim)
            c.drawRect(l, t, r, b, stroke)
        }
        c.drawText("ناحیه اسکن را با کشیدن انگشت مشخص کنید", w / 2, h * 0.12f, label)
        c.drawText("(لمس ساده = لغو)", w / 2, h * 0.12f + 64f, label2)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x; sy = e.y; ex = sx; ey = sy; dragging = true; invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                ex = e.x; ey = e.y; invalidate()
            }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y; dragging = false
                val loc = IntArray(2)
                getLocationOnScreen(loc)
                val r = Rect(
                    min(sx, ex).toInt() + loc[0], min(sy, ey).toInt() + loc[1],
                    max(sx, ex).toInt() + loc[0], max(sy, ey).toInt() + loc[1]
                )
                onResult(if (r.width() > 40 && r.height() > 40) r else null)
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; onResult(null) }
        }
        return true
    }
}
