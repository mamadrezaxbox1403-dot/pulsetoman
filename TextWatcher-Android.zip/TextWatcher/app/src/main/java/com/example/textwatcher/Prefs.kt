package com.example.textwatcher

import android.content.Context
import android.graphics.Rect

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var intervalSec: Float
        get() = sp.getFloat("interval", 1.5f)
        set(v) { sp.edit().putFloat("interval", v).apply() }

    var minChars: Int
        get() = sp.getInt("minChars", 3)
        set(v) { sp.edit().putInt("minChars", v).apply() }

    var alarmSecs: Int
        get() = sp.getInt("alarmSecs", 8)
        set(v) { sp.edit().putInt("alarmSecs", v).apply() }

    /** 0 = until tapped */
    var animSecs: Int
        get() = sp.getInt("animSecs", 10)
        set(v) { sp.edit().putInt("animSecs", v).apply() }

    var message: String
        get() = sp.getString("message", "متن تشخیص داده شد!") ?: "متن تشخیص داده شد!"
        set(v) { sp.edit().putString("message", v).apply() }

    /** 0 = top, 1 = center, 2 = bottom */
    var position: Int
        get() = sp.getInt("position", 0)
        set(v) { sp.edit().putInt("position", v).apply() }

    var borderFlash: Boolean
        get() = sp.getBoolean("borderFlash", true)
        set(v) { sp.edit().putBoolean("borderFlash", v).apply() }

    var vibrate: Boolean
        get() = sp.getBoolean("vibrate", true)
        set(v) { sp.edit().putBoolean("vibrate", v).apply() }

    var soundUri: String?
        get() = sp.getString("sound", null)
        set(v) {
            if (v == null) sp.edit().remove("sound").apply()
            else sp.edit().putString("sound", v).apply()
        }

    var region: Rect?
        get() {
            val s = sp.getString("region", null) ?: return null
            val p = s.split(",")
            if (p.size != 4) return null
            return try { Rect(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt()) } catch (e: Exception) { null }
        }
        set(v) {
            if (v == null) sp.edit().remove("region").apply()
            else sp.edit().putString("region", "${v.left},${v.top},${v.right},${v.bottom}").apply()
        }
}
