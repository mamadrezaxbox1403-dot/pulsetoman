package com.example.textwatcher

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator

class AlarmPlayer(private val ctx: Context) {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    private fun create(uri: Uri): MediaPlayer = MediaPlayer().apply {
        setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        setDataSource(ctx, uri)
        isLooping = true
        prepare()
        start()
    }

    fun start(soundUri: String?, vibrate: Boolean) {
        stop()
        val default = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        player = try {
            create(if (soundUri != null) Uri.parse(soundUri) else default)
        } catch (e: Exception) {
            try { create(default) } catch (e2: Exception) { null }
        }
        if (vibrate) {
            @Suppress("DEPRECATION")
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300), 0))
            vibrator = v
        }
    }

    fun stop() {
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
        vibrator?.cancel()
        vibrator = null
    }
}
