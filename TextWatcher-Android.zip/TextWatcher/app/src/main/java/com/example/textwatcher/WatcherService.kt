package com.example.textwatcher

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executor
import kotlin.math.max
import kotlin.math.sin

class WatcherService : Service() {

    companion object {
        const val ACTION_START = "com.example.textwatcher.START"
        const val ACTION_STOP = "com.example.textwatcher.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("capture")
    private lateinit var bg: Handler
    private val exec = Executor { r -> bg.post(r) }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var frame: Bitmap? = null
    private var convScheduled = false
    private var closing = false

    @Volatile private var scanning = false
    @Volatile private var prevHas: Boolean? = null
    @Volatile private var alertShowing = false

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val alarm by lazy { AlarmPlayer(this) }

    private var bar: View? = null
    private var statusView: TextView? = null
    private var startBtn: TextView? = null
    private var selector: View? = null
    private var banner: View? = null
    private var border: View? = null
    private val animators = mutableListOf<ValueAnimator>()

    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                startForegroundCompat()
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
                if (data == null || !setupProjection(code, data)) {
                    shutdown(); return START_NOT_STICKY
                }
                running = true
                showBar()
            }
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ setup

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("watch", "Watcher", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, WatcherService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, "watch")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("ناظر متن فعال است")
            .setContentText("برای توقف، «توقف» را بزنید")
            .addAction(0, "توقف", stopPi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(1, n)
    }

    private fun setupProjection(code: Int, data: Intent): Boolean {
        return try {
            thread.start()
            bg = Handler(thread.looper)
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { shutdown() } }
            }, bg)

            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
            r.setOnImageAvailableListener({ onFrameAvailable() }, bg)
            virtualDisplay = p.createVirtualDisplay(
                "textwatcher", dm.widthPixels, dm.heightPixels, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, bg
            )
            projection = p
            reader = r
            true
        } catch (e: Exception) {
            toast("خطا در شروع ضبط صفحه: ${e.message}")
            false
        }
    }

    // ----------------------------------------------------------------- frames

    private fun onFrameAvailable() {
        if (convScheduled) return
        convScheduled = true
        bg.postDelayed({ convScheduled = false; convertLatest() }, 150)
    }

    private fun convertLatest() {
        val img = try { reader?.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val tmp = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
            tmp.copyPixelsFromBuffer(plane.buffer)
            val fresh = if (rowPixels != img.width) {
                Bitmap.createBitmap(tmp, 0, 0, img.width, img.height).also { tmp.recycle() }
            } else tmp
            val old = frame
            frame = fresh
            old?.recycle()
        } catch (e: Exception) {
            // ignore a bad frame
        } finally {
            img.close()
        }
    }

    // --------------------------------------------------------------- scanning

    private val tick = Runnable { scanOnce() }

    private fun startScanning() {
        if (prefs.region == null) { toast("ابتدا ناحیه را انتخاب کنید (دکمه ⛶)"); return }
        prevHas = null
        scanning = true
        updateBar("در حال اسکن…")
        bg.removeCallbacks(tick)
        bg.post(tick)
    }

    private fun stopScanning() {
        scanning = false
        if (::bg.isInitialized) bg.removeCallbacks(tick)
        updateBar("متوقف")
    }

    private fun scheduleNext(t0: Long) {
        if (!scanning) return
        val wait = max(50L, (prefs.intervalSec * 1000).toLong() - (SystemClock.elapsedRealtime() - t0))
        bg.postDelayed(tick, wait)
    }

    private fun scanOnce() {
        if (!scanning) return
        val t0 = SystemClock.elapsedRealtime()
        convertLatest()
        val f = frame
        val reg = prefs.region
        if (f == null || reg == null || alertShowing) { scheduleNext(t0); return }

        val l = reg.left.coerceIn(0, f.width - 2)
        val t = reg.top.coerceIn(0, f.height - 2)
        val w = (reg.right - l).coerceIn(1, f.width - l)
        val h = (reg.bottom - t).coerceIn(1, f.height - t)
        var crop = Bitmap.createBitmap(f, l, t, w, h)
        if (crop === f) crop = f.copy(Bitmap.Config.ARGB_8888, false)

        recognizer.process(InputImage.fromBitmap(crop, 0)).addOnCompleteListener(exec) { task ->
            crop.recycle()
            if (task.isSuccessful) {
                val text = task.result.text
                val has = text.count { !it.isWhitespace() } >= prefs.minChars
                val before = prevHas
                prevHas = has
                if (before == false && has && scanning) main.post { triggerAlert() }
                val preview = text.replace("\n", " ").trim().take(30)
                updateBar(if (has) "متن: $preview" else "بدون متن")
            } else {
                updateBar("خطای OCR")
            }
            scheduleNext(t0)
        }
    }

    // ------------------------------------------------------------------ alert

    private val autoStopAlarm = Runnable { alarm.stop() }
    private val autoDismiss = Runnable { dismissAlert() }

    private fun triggerAlert() {
        if (alertShowing) return
        alertShowing = true
        alarm.start(prefs.soundUri, prefs.vibrate)
        showBanner()
        if (prefs.borderFlash) showBorder()
        main.postDelayed(autoStopAlarm, prefs.alarmSecs.coerceAtLeast(1) * 1000L)
        if (prefs.animSecs > 0) main.postDelayed(autoDismiss, prefs.animSecs * 1000L)
    }

    private fun dismissAlert() {
        main.removeCallbacks(autoStopAlarm)
        main.removeCallbacks(autoDismiss)
        alarm.stop()
        animators.forEach { it.cancel() }
        animators.clear()
        removeView(banner); banner = null
        removeView(border); border = null
        alertShowing = false
        prevHas = null // re-baseline after the alert
    }

    private fun pulse(update: (Float) -> Unit) {
        val a = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 600
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { update(it.animatedValue as Float) }
        }
        animators.add(a)
        a.start()
    }

    private fun blend(a: Int, b: Int, f: Float): Int = ArgbEvaluator().evaluate(f, a, b) as Int

    private fun showBanner() {
        val tv = TextView(this).apply {
            text = "⚠  ${prefs.message}"
            setTextColor(Color.WHITE)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        val bgd = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(0xFFB91C1C.toInt())
        }
        tv.background = bgd
        tv.setOnClickListener { dismissAlert() }
        val box = FrameLayout(this).apply {
            setPadding(dp(12), 0, dp(12), 0)
            addView(tv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            when (prefs.position) {
                0 -> { gravity = Gravity.TOP; y = dp(48) }
                2 -> { gravity = Gravity.BOTTOM; y = dp(64) }
                else -> gravity = Gravity.CENTER
            }
        }
        wm.addView(box, lp)
        banner = box
        pulse { f ->
            bgd.setColor(blend(0xFF7F1D1D.toInt(), 0xFFEF4444.toInt(), f))
            tv.translationX = (sin(f * 12.0) * dp(4)).toFloat()
        }
    }

    private fun showBorder() {
        val v = View(this)
        val gd = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(14), Color.RED)
        }
        v.background = gd
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        border = v
        pulse { f -> gd.setStroke(dp(14), blend(0xFF7F1D1D.toInt(), 0xFFFF2D2D.toInt(), f)) }
    }

    // --------------------------------------------------------- floating bar

    private fun showBar() {
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(2))
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                setColor(0xEE111827.toInt())
                setStroke(dp(1), 0xFF374151.toInt())
            }
        }
        fun label(t: String, size: Float = 14f) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = size
            setPadding(dp(11), dp(10), dp(11), dp(10))
        }

        val handle = label("⠿", 18f)
        val regionBtn = label("⛶ ناحیه").apply { setOnClickListener { selectRegion() } }
        val start = label("▶ شروع").apply {
            setOnClickListener { if (scanning) stopScanning() else startScanning() }
        }
        val status = label("آماده", 12f).apply { setTextColor(0xFF9CA3AF.toInt()) }
        val close = label("✕").apply { setOnClickListener { shutdown() } }
        listOf(handle, regionBtn, start, status, close).forEach { ll.addView(it) }
        startBtn = start
        statusView = status

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = dp(8); y = dp(140)
        }
        handle.setOnTouchListener(object : View.OnTouchListener {
            var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ix + (e.rawX - tx).toInt()
                        lp.y = iy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(ll, lp) } catch (_: Exception) {}
                    }
                }
                return true
            }
        })
        wm.addView(ll, lp)
        bar = ll
        toast("نوار شناور فعال شد. به برنامه مورد نظر بروید.")
    }

    private fun updateBar(status: String) {
        main.post {
            statusView?.text = status
            startBtn?.text = if (scanning) "■ توقف" else "▶ شروع"
        }
    }

    private fun selectRegion() {
        if (selector != null) return
        stopScanning()
        bar?.visibility = View.GONE
        val v = RegionSelectView(this) { rect ->
            main.post {
                removeView(selector); selector = null
                bar?.visibility = View.VISIBLE
                if (rect != null) {
                    prefs.region = rect
                    toast("ناحیه ذخیره شد (${rect.width()}×${rect.height()}). حالا ▶ را بزنید")
                    updateBar("ناحیه آماده")
                } else toast("لغو شد")
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        selector = v
    }

    // ---------------------------------------------------------------- helpers

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        main.post { Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show() }
    }

    private fun shutdown() {
        if (closing) return
        closing = true
        scanning = false
        dismissAlert()
        removeView(bar); bar = null
        removeView(selector); selector = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        frame?.recycle(); frame = null
        if (::bg.isInitialized) thread.quitSafely()
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
